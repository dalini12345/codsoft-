import random
import string

print("--- PASSWORD GENERATOR ---")
length = int(input("Enter password length: "))

all_chars = string.ascii_letters + string.digits + string.punctuation
password = "".join(random.sample(all_chars, length))

print("Generated Password:", password)
