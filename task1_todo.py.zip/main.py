todo_list = []

def show_menu():
    print("\n--- TO-DO LIST ---")
    print("1. View Tasks")
    print("2. Add Task")
    print("3. Remove Task")
    print("4. Exit")

while True:
    show_menu()
    choice = input("Choose an option: ")

    if choice == "1":
        if not todo_list:
            print("No tasks yet.")
        else:
            for idx, task in enumerate(todo_list):
                print(f"{idx + 1}. {task}")

    elif choice == "2":
        task = input("Enter task: ")
        todo_list.append(task)
        print("Task added.")

    elif choice == "3":
        if not todo_list:
            print("No tasks to remove.")
        else:
            index = int(input("Enter task number to remove: "))
            if 0 < index <= len(todo_list):
                removed = todo_list.pop(index - 1)
                print(f"Removed task: {removed}")
            else:
                print("Invalid number.")

    elif choice == "4":
        print("Goodbye!")
        break

    else:
        print("Invalid choice.")
